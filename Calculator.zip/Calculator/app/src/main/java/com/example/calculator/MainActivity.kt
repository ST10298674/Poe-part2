package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.math.pow
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find and initialize the UI elements
        val number1 = findViewById<EditText>(R.id.editTextNumber)
        val number2 = findViewById<EditText>(R.id.editTextNumber2)
        val addButton = findViewById<Button>(R.id.button)
        val subtractButton = findViewById<Button>(R.id.button2)
        val multiplyButton = findViewById<Button>(R.id.button3)
        val divideButton = findViewById<Button>(R.id.button4)
        val squareRootButton = findViewById<Button>(R.id.button5)
        val powerButton = findViewById<Button>(R.id.button6)
        val answerTextView = findViewById<TextView>(R.id.textView3)

        // Set up click listeners for the operation buttons
        addButton.setOnClickListener {

            val num1 = number1.text.toString().toIntOrNull() ?: return@setOnClickListener
            val num2 = number2.text.toString().toIntOrNull() ?: return@setOnClickListener
            // Perform addition and display the result
            val result = num1 + num2
            answerTextView.text = "Answer: $num1 + $num2 = $result"
        }

        subtractButton.setOnClickListener {

            val num1 = number1.text.toString().toIntOrNull() ?: return@setOnClickListener
            val num2 = number2.text.toString().toIntOrNull() ?: return@setOnClickListener

            val result = num1 - num2
            answerTextView.text = "Answer: $num1 - $num2 = $result"
        }

        multiplyButton.setOnClickListener {

            val num1 = number1.text.toString().toIntOrNull() ?: return@setOnClickListener
            val num2 = number2.text.toString().toIntOrNull() ?: return@setOnClickListener

            val result = num1 * num2
            answerTextView.text = "Answer: $num1 * $num2 = $result"
        }

        divideButton.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toDouble()
            if (num2 != 0.0) {

                val result = num1 / num2
                answerTextView.text = "Answer: $num1 / $num2 = $result"
            } else {

                answerTextView.text = "Can't divide by zero"
            }
        }

        squareRootButton.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            if (num1 >= 0) {
                val result = sqrt(num1)
                answerTextView.text = "sqrt($num1) = $result"
            } else {
                val absNum1 = kotlin.math.abs(num1)
                val result = "${sqrt(absNum1)} i"
                answerTextView.text = "sqrt($num1) = $result"
            }
        }

        powerButton.setOnClickListener {
            val num1 = number1.text.toString().toDouble()
            val num2 = number2.text.toString().toIntOrNull() ?: return@setOnClickListener
            val result = num1.pow(num2)
            answerTextView.text = "$num1^$num2 = $result"
        }
    }

}